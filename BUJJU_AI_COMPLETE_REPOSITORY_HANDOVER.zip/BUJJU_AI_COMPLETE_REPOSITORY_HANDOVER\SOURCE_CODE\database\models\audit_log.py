﻿"""
Enterprise Audit Log ORM Model
Sprint 6
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import DateTime
from sqlalchemy import Float
from sqlalchemy import Integer
from sqlalchemy import JSON
from sqlalchemy import String
from sqlalchemy import Text
from sqlalchemy.orm import Mapped, validates
from sqlalchemy.orm import mapped_column, validates

from database.base import Base


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    @validates("id")
    def _validate_id(self, key, value):
        return str(value) if value is not None else None


    tenant_id: Mapped[str | None] = mapped_column(String(36), index=True, nullable=True)
    organization_id: Mapped[str | None] = mapped_column(String(36), nullable=True)

    user_id: Mapped[str | None] = mapped_column(String(36), index=True, nullable=True)

    username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    role_name: Mapped[str | None] = mapped_column(String(150), nullable=True)

    session_id: Mapped[str | None] = mapped_column(String(255), index=True, nullable=True)
    request_id: Mapped[str | None] = mapped_column(String(255), index=True, nullable=True)
    correlation_id: Mapped[str | None] = mapped_column(String(255), index=True, nullable=True)
    trace_id: Mapped[str | None] = mapped_column(String(255), nullable=True)

    action: Mapped[str] = mapped_column(String(120), index=True)
    event_type: Mapped[str] = mapped_column(String(120), index=True)

    resource_type: Mapped[str | None] = mapped_column(String(150), index=True, nullable=True)
    resource_id: Mapped[str | None] = mapped_column(String(255), index=True, nullable=True)
    resource_name: Mapped[str | None] = mapped_column(String(255), nullable=True)

    module: Mapped[str | None] = mapped_column(String(150), nullable=True)
    endpoint: Mapped[str | None] = mapped_column(String(500), nullable=True)
    http_method: Mapped[str | None] = mapped_column(String(20), nullable=True)

    status: Mapped[str] = mapped_column(String(50), index=True)
    status_code: Mapped[int | None] = mapped_column(Integer, nullable=True)

    message: Mapped[str | None] = mapped_column(Text, nullable=True)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)

    before_data: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    after_data: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    metadata_: Mapped[dict[str, Any] | None] = mapped_column("metadata", JSON, nullable=True)

    client_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    forwarded_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(Text, nullable=True)

    device: Mapped[str | None] = mapped_column(String(255), nullable=True)
    browser: Mapped[str | None] = mapped_column(String(255), nullable=True)
    platform: Mapped[str | None] = mapped_column(String(255), nullable=True)

    country: Mapped[str | None] = mapped_column(String(150), nullable=True)
    city: Mapped[str | None] = mapped_column(String(150), nullable=True)

    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)

    request_body: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    query_params: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    headers: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)

    response_time_ms: Mapped[float | None] = mapped_column(Float, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        index=True,
    )


